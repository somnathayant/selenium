/**
 * 
 */
/**
 * @author somnath
 *
 */
package com.ayantsoft.testNGMavenExample.pojo;