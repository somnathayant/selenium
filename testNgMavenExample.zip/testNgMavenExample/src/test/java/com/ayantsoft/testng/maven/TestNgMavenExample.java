package com.ayantsoft.testng.maven;

import org.testng.annotations.Test;

public class TestNgMavenExample {

	@Test
	public void exampleOfTestNgMaven() {
		System.out.println("This is TestNG-Maven Example");
	}
}
