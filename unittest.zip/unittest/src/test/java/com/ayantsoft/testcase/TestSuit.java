package com.ayantsoft.testcase;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({TestCase2.class,TestCase3.class})
public class TestSuit {

	
	
	
}
