package com.ayantsoft.Selenium.webpage;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;



//This program shows the use of Anchar links with broken links
//right click on this file and select run as either java application or testNG

public class Anchor_Links {

	
	public static void main(String args[]){
		// TODO Auto-generated method stub

		WebDriver driver=new FirefoxDriver();
		//broken link test
		String baseUrl = "http://localhost:8082/seleniumUltimate/";	
		driver.get(baseUrl);

		HttpURLConnection huc = null;
		String url = "";
		int respCode = 200;

		String ancharName="";

		List<WebElement> links = driver.findElements(By.tagName("a"));

		Iterator<WebElement> it = links.iterator();

		while(it.hasNext()){

			url = it.next().getAttribute("href");

			ancharName=it.next().getText();

			if(url == null || url.isEmpty()){
				System.out.println("URL is either not configured for anchor tag or it is empty");

			}

			try {
				huc = (HttpURLConnection)(new URL(url).openConnection());

				huc.setRequestMethod("HEAD");

				huc.connect();

				respCode = huc.getResponseCode();

				if(respCode >= 400){
					System.out.println(ancharName+" "+url+" is a broken link");
				}
				else{
					System.out.println(ancharName+" "+url+" is a valid link");
				}

			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	}

	@Test
	public static void ancharTest() {
		// TODO Auto-generated method stub

		WebDriver driver=new FirefoxDriver();
		//broken link test
		String baseUrl = "http://localhost:8082/seleniumUltimate/";	
		driver.get(baseUrl);

		HttpURLConnection huc = null;
		String url = "";
		int respCode = 200;

		String ancharName="";

		List<WebElement> links = driver.findElements(By.tagName("a"));

		Iterator<WebElement> it = links.iterator();

		while(it.hasNext()){

			url = it.next().getAttribute("href");

			ancharName=it.next().getText();

			if(url == null || url.isEmpty()){
				System.out.println("URL is either not configured for anchor tag or it is empty");

			}

			try {
				huc = (HttpURLConnection)(new URL(url).openConnection());

				huc.setRequestMethod("HEAD");

				huc.connect();

				respCode = huc.getResponseCode();

				if(respCode >= 400){
					System.out.println(ancharName+" "+url+" is a broken link");
				}
				else{
					System.out.println(ancharName+" "+url+" is a valid link");
				}

			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


		// driver.close();
	}




}


