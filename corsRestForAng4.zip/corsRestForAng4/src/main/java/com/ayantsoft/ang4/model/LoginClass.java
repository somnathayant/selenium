package com.ayantsoft.ang4.model;

public class LoginClass {
	private String userId;
	private String password;
	
	//setter and getter method
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
}
