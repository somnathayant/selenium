package com.ayantsoft.ang4.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.ang4.model.LoginClass;
import com.ayantsoft.ang4.model.LoginMst;
import com.ayantsoft.ang4.model.Student;


//as the class is annotated using @RestController now all the controller methods can be accessd by ip address
@RestController
public class UserController{

	

@RequestMapping(value="/",method=RequestMethod.GET)
public ModelAndView index(){
	ModelAndView mv = new ModelAndView("index");
	return mv;
}


@RequestMapping(value="/getEmpData",method=RequestMethod.POST)//http://localhost:8081/corsRestForAng4/getStudentData
public ResponseEntity<?> getEmpData(@RequestBody Emp empObj){//here data received using @requestBody
	
	
	System.out.println("========");
	System.out.println(empObj.getEmpName());
	System.out.println(empObj.getEmpRoll());
	System.out.println("=========");
	
	HttpStatus httpStatus = null;
	
	List<Emp>empList=new ArrayList<Emp>();
	
	Emp e1=new Emp();
		e1.setEmpName("somnath Biswas");
		e1.setEmpRoll(22);
	Emp e2=new Emp();
		e2.setEmpName("Animesh Choudhary");
		e2.setEmpRoll(20);
		
	empList.add(e1);
	empList.add(e2);
	
	httpStatus=HttpStatus.OK;
	return new ResponseEntity<List<Emp>>(empList,httpStatus);
}


}
